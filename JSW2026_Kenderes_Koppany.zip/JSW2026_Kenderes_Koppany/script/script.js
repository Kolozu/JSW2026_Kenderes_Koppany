'use strict';

document.addEventListener('DOMContentLoaded', function() {
    const categoryFilters = document.querySelectorAll('.category-filter');
    const productSections = document.querySelectorAll('.card-grid');
    const introduction = document.querySelector('.introduction');
    const calculator = document.querySelector('.calculator');
    
    categoryFilters.forEach(filter => {
        filter.addEventListener('click', function() {
            categoryFilters.forEach(f => f.classList.remove('active'));
            this.classList.add('active');
            
            const selectedCategory = this.dataset.category;
            
            if (selectedCategory === 'all') {
                productSections.forEach(section => {
                    section.style.display = 'grid';
                });
                document.querySelectorAll('.products h2').forEach(h2 => {
                    h2.style.display = 'block';
                });
            } else {
                productSections.forEach(section => {
                    if (section.dataset.category === selectedCategory) {
                        section.style.display = 'grid';
                        const prevH2 = section.previousElementSibling;
                        if (prevH2 && prevH2.tagName === 'H2') {
                            prevH2.style.display = 'block';
                        }
                    } else {
                        section.style.display = 'none';
                        const prevH2 = section.previousElementSibling;
                        if (prevH2 && prevH2.tagName === 'H2') {
                            prevH2.style.display = 'none';
                        }
                    }
                });
            }
        });
    });
    
    const form = document.getElementById('packingForm');
    const dialog = document.getElementById('resultDialog');
    const closeBtn = document.getElementById('closeDialog');
    const resultText = document.getElementById('resultText');
    
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const length = parseFloat(document.getElementById('length').value);
        const width = parseFloat(document.getElementById('width').value);
        const height = parseFloat(document.getElementById('height').value);
        
        let isValid = true;
        let errorMessage = '';
        
        if (isNaN(length) || length <= 0) {
            errorMessage += 'A hosszúság csak pozitív szám lehet!\n';
            isValid = false;
        }
        
        if (isNaN(width) || width <= 0) {
            errorMessage += 'A szélesség csak pozitív szám lehet!\n';
            isValid = false;
        }
        
        if (isNaN(height) || height <= 0) {
            errorMessage += 'A magasság csak pozitív szám lehet!\n';
            isValid = false;
        }
        
        if (!isValid) {
            alert(errorMessage);
            return;
        }
        
        const volume = (length * width * height) / 1000; 

        resultText.textContent = `A becsült szükséges térkitöltő anyag mennyisége: ${volume.toFixed(2)} liter.`;

        form.reset();

        dialog.showModal();
    });
    
    closeBtn.addEventListener('click', function() {
        dialog.close();
    });

    dialog.addEventListener('click', function(e) {
        const dialogRect = dialog.getBoundingClientRect();
        if (
            e.clientX < dialogRect.left ||
            e.clientX > dialogRect.right ||
            e.clientY < dialogRect.top ||
            e.clientY > dialogRect.bottom
        ) {
            dialog.close();
        }
    });
    
    const allH2 = document.querySelectorAll('h2');
    let counter = 1;
    allH2.forEach((h2, index) => {
        if (index > 0 && index < allH2.length - 1) {
            h2.textContent = `${counter}. ${h2.textContent}`;
            counter++;
        }
    });
});